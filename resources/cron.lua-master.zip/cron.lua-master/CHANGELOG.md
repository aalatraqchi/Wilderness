# cron.lua changelog

## v 2.0.0

* Removed all 'tagged' subsystems
* Removed all internal management of state (entries). Invididual clocks are now exposed to the user directly.

